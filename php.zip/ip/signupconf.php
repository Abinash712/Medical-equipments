<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>RecMed</title>

<style type="text/css">
    body {
		font-family: 'Varela Round', sans-serif;
	}
	.container1 {		
		
		width: 700px;
		height: 380px;
		position: relative;
		margin:0px 0px 50px 400px;
		
		border-radius: 5px 5px 0 0;
		padding: 35px;
		background: #66d9ff;
	}
	
	
</style>
</head>
<body>

<?php include "navbar1.php" ?>
			<br><br><br>
			<div class="container1">
			<br><br>
			<br>
			<div class="modal-body text-center">
				<h3>Great!</h3>	<br>
				<h5>Your account has been created successfully.</h5><br>
				<a class="btn btn-large btn-success" href="login.php">Click here to Login</a>
			</div>
		</div> 
		<?php include "footer.php" ?>    
</body>
</html>                                                        