<?php
  $msg='';
  if(filter_has_var(INPUT_POST,"submit"))
  {
    
    $mail=$_POST['email'];
    $pass=$_POST['password'];
    $servername = "localhost";
$username = "root";
$password = "";
$db="medical";
$conn = mysqli_connect($servername, $username, $password,$db);
if ($conn) {
    $sql = "SELECT * FROM signup where email='$mail'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) 
    {
        while($row = mysqli_fetch_assoc($result)) {
          session_start();
          if($row['password']=='adminrecmed')
          {
            $_SESSION['user']=$mail;
            header("Location:addproducts.php");
          }
         elseif($row['password']==$pass)
         {
            
            $_SESSION['user']=$mail;

            header("Location:display.php");
         }
         else
         {
          $msg="Incorrect password";
         }
    }
    }
    else
    {
      $msg="Invalid email id";
    }
}
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>RecMed</title>
<style type="text/css">
  body {
    color: #4e4e4e;
    background: #001133;
    font-family: 'Roboto', sans-serif;
  }
    .form-control {
    background: #f2f2f2;
        font-size: 16px;
    border-color: transparent;
    box-shadow: none !important;
  }
  .form-control:focus {
    border-color: #91d5a8;
        background: #e9f5ee;
  }
    .form-control, .btn {        
        border-radius: 2px;
    }
  .login-form {
    width: 380px;
    margin: 0 auto;
  }
    .login-form h2 {
        margin: 0;
        padding: 30px 0;
        font-size: 34px;
    }
  .login-form .avatar {
    margin: 0 auto 30px;
    width: 100px;
    height: 100px;
    border-radius: 50%;
    z-index: 9;
    
    
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1);
  }
  .login-form .avatar img {
    width: 100%;
  }
    .login-form form {
    color: #7a7a7a;
    border-radius: 4px;
      margin-bottom: 20px;
        background: #fff;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;    
    }
    .login-form .btn {
    font-size: 16px;
    line-height: 26px;
    min-width: 120px;
        font-weight: bold;
    background: #4aba70;
    border: none;   
    }
  .login-form .btn:hover, .login-form .btn:focus{
    background: #40aa65;
        outline: none !important;
  }
  .checkbox-inline {
    margin-top: 14px;
  }
  .checkbox-inline input {
    margin-top: 3px;
  }
    .login-form a {
    color: #4aba70;
  } 
  .login-form a:hover {
    text-decoration: underline;
  }
  .hint-text {
    color: #999;
        text-align: center;
    padding-bottom: 15px;
  }
  .bcolor{
    background-image: url("slide5.jpg");
    height:515px;
  }
</style>
</head>
<body>
<?php include "navbar1.php"; ?>
<div class="bcolor">
<div class="login-form">
  <h2 class="text-center color">Login</h2>
    <form action="login.php" method="post">
    <div class="avatar">
      <img src="avatar4.png" alt="Avatar">
    </div> 
    <?php if($msg!=''): ?>
      <div class="alert alert-danger"><?php echo $msg; ?></div>
  <?php endif; ?>          
        <div class="form-group">
          <input type="text" class="form-control input-lg" name="email" placeholder="Email" required="required">  
        </div>
    <div class="form-group">
            <input type="password" class="form-control input-lg" name="password" placeholder="Password" required="required">
        </div>        
        <div class="form-group clearfix">
      <label class="pull-left checkbox-inline"><input type="checkbox"> Remember me</label>
            <button type="submit" class="btn btn-primary btn-lg pull-right" name="submit">Sign in</button>
        </div>    
    </form>
  <div class="hint-text">Don't have an account? <a href="#">Sign up here</a></div>
</div>
</div>
<?php include "footer.php"; ?>
</body>
</html>                            