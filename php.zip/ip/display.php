<!DOCTYPE html>
<html lang="en">
<head>
  <title>RecMed</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://kit.fontawesome.com/18803c92e0.js" crossorigin="anonymous"></script>
  <style type="text/css">
  	.card{
  		height:325px;

  	}
  	#img1{
  		height:200px;
  		width:200px;
  		margin:0px 0px 10px 10px;
  	}
  	#cart{
  		width:108px;
  		float:right;
  		box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
  		margin: 0px 10px 0px 0px;
  	}
  	#view{
  		width:108px;
  		float:left;
  		box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
  		margin: 0px 0px 0px 10px;
  	}
  </style>
</head>
<body>
	<?php include "navbar.php" ?>
	<br>
	<div class="container">
	<div class="row">




<?php

include "dbconnect.php";
if($conn)
{
	session_start();
	$query="select * from products";
	$result=mysqli_query($conn,$query);
	if( mysqli_num_rows($result)>0)
	{
		while($row=mysqli_fetch_assoc($result))
		{ ?>

		<div class="col-lg-3 col-sm-2">
			<form method="Post">
			<div class="card">
				<h4 class="card-title"><?php echo ucwords($row['product_name']); ?> </h4>
				<div class="class-body">
					<img src="<?php echo $row['image']; ?>" alt="image" class="img-fluid" id="img1"></div>
					<h6>&#8377; <?php echo $row['product_price']; ?> </h6>
					<div>
					<button class="btn btn-info" id="view" formaction="view.php" value="<?php echo $row['product_Id']; ?>" name="view">View</button>  
					<button class="btn btn-danger" id="cart" formaction="#">Wishlist</button>
				</div>
			</div>
		</form>
		<br><br>
	</div>

	<?php
		}
	}
}

?>
</div>
<br>
</div>
<?php include "footer.php"; ?>
</body>
</html>