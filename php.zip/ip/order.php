<!DOCTYPE html>
<html lang="en">
<head>
  <title>RecMed</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://kit.fontawesome.com/18803c92e0.js" crossorigin="anonymous"></script>
  <style type="text/css">
  	#tab{
  		width:300px;
  	}
  	#thead{
  		width:700px;
  		text-align: center;
  	}
  	#img1{
  		height:300px;
  		width:300px;
  		margin:40px 40px 40px 40px;
  	}
  	.imgg{
  		height:500px;
  		width:1400px;
  		margin-left:60px;
  		border-color:blue;
  	}
  		
  	.ind1{
  		margin-left:70px;
  		margin-top: -140px;
  	}
  	.add{
  		margin-left:30px;

  	}
  	
  	
	.image{
		margin-top: 15px;
		border:1px solid;
	}
	#place
	{
		margin-left: 70px;
	}
  </style>
 </head>
 <body>
 	<?php include "navbar.php"; ?>
<?php
	include "dbconnect.php";
	if($conn)
	{
		session_start();
		$id=$_SESSION['id'];
	$query="SELECT * from products where product_Id=$id";
	$result=mysqli_query($conn,$query);
	if(mysqli_num_rows($result)>0)
	{
		while($row=mysqli_fetch_assoc($result))
		{ ?>
			<br>
			<h2 align="center"><?php echo ucwords($row['product_name']); ?> </h2>
			<hr>
			<br>
			<form method="post">
			<div class="imgg">
				<div class="row">
					<div class="col-md-4">
						<div class="image">
			
				<img src="<?php echo $row['image']; ?>" alt="image" class="img-fluid" id="img1">
			</div>
			</div>
			<div class="col-md-4">
				<div class="ind1">
			
				
					<br><br><br><br><br><br>
				
				<table class="table table-borderless" id="tab">
					<tr><td></td></tr>
					<thead class="thead-dark">
						<tr>
						<th id="thead" colspan="2">order</th>
					</tr>
					</thead>
					<tr>
						<th>Price</th>
						<td align="right"><?php echo $row['product_price']; ?></td>
					</tr>
					<tr>
						<th>Quantity</th>
						<td align="right"><?php echo $_POST['quan']; ?></td>
					</tr>
					<tr>
						<th>Discount</th>
						<td align="right">-<?php echo $row['discount']; ?>%</td>
					</tr>
					<tr>
						<th>Order Total</th>
						<td align="right"><?php $cost=($row['product_price']*$_POST['quan'])-(($row['discount']*$row['product_price'])/100); echo $cost ?></td>
					</tr>
					<tr>
						<th>Delivery charge</th>
						<td align="right"><?php $dcost=40; echo $dcost; ?></td>
					</tr>
					<tr><td colspan="2">-------------------------------------------</td></tr>
					<tr>
						<th>Total</th>
						<td align="right"><h6><?php echo $cost+$dcost; ?></h6></td>
					</tr>
					
				</table>
				<br>
				<button type="submit" class="btn btn-success" id="place" name="place" formaction="orderconf.php" value="<?php echo $cost+$dcost; ?>">Place your Order</button>
				</div>
			</div>
			<div class="col-md-4">
				<div class="add">
				<form method="post">
					<div id="ship">
				<h4 align="center">shipping Address</h4>
				<br>
				
				<div class="form-group">
					  <h6>Address Line 1:</h6>
					  <input type="text" class="form-control" name="add1" placeholder="Flat/door no,Street name" required="required">
				</div>
				<div class="form-group">
					  <h6>Address Line 2:</h6>
					  <input type="text" class="form-control" name="add2" placeholder="Area,City" required="required">
				</div>
				<div class="form-group">
				        <h6>State</h6>
				        <select class="form-control" name="state">
				        <option>Assam</option>
				        <option>Karnataka</option>
				        <option>Kerala</option>
				        <option>Tamil Nadu</option>
				      </select>
				 </div>
				 <div class="form-group">
					  <h6>Pincode</h6>
					  <input type="number" class="form-control" name="pin" placeholder="pincode" required="required">
				</div>

			</form>
		</div>
			</div>

			</div>
		</div>

			</div>





<?php
		}
	}
}
?>

<?php include "footer.php"; ?>
</body>
</html>





