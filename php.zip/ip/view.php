<!DOCTYPE html>
<html lang="en">
<head>
  <title>RecMed</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://kit.fontawesome.com/18803c92e0.js" crossorigin="anonymous"></script>
  <style type="text/css">
  	.imgg{
  		height:800px;
  		width:1300px;
  		margin-left:60px;
  		border-color:blue;
  	}
  		
  	.ind{
  		margin-left:200px;
  	}
  	#img1{
  		height:400px;
  		width:400px;
  		margin-top: 60px;
  		border:1px groove;
  	}
  	.desc{
  		background: red;
  		width:50px;
  		height:50px;
  	}
  	.buy{
  		margin-left: 200px;
  	}
  	#buy1{
  		width:200px;
  	}
  	.third
  	{
  		margin:130px 0px 0px 0px;
  		
  	}
  	.center{
  		text-align: center;
  	}
    </style>

</head>
<body>
<?php include "navbar.php"; ?>
<?php
	include "dbconnect.php";
	if($conn)
	{
		session_start();
	$id=$_POST['view'];
	$_SESSION['id']=$id;
	$query="SELECT * from products where product_Id=$id";
	$result=mysqli_query($conn,$query);
	if(mysqli_num_rows($result)>0)
	{
		while($row=mysqli_fetch_assoc($result))
		{ ?>
			<form method="post">
			<div class="imgg">
				<div class="row">
					<div class="col-md-3">
				
				<img src="<?php echo $row['image']; ?>" alt="image" class="img-fluid" id="img1">
			</div>
			<div class="col-md-6">
				<div class="ind1">
			
				
					<br><br><br><br><br><br>
				<h2><?php echo ucwords($row['product_name']); ?> </h2>
				<h5 class="text-success">Price:</h5>
				<div class="input-group">
				<h4><b>&#8377;<?php echo $row['product_price']; ?></b></h4><pre>  </pre>
				<button class="btn btn-success"><?php echo $row['discount']; ?>% Off</h4>
				</div>
				<br>

				<h6><span><i class='fas fa-tag' style='color:green'></i></span> Bank Offer5% Unlimited Cashback on Flipkart Axis Bank Credit CardT&C</h6>

				<h6><span><i class='fas fa-tag' style='color:green'></i></span> Bank Offer10% Cashback* on HDFC Bank Debit CardsT&C</h6>

				<h6><span><i class='fas fa-tag' style='color:green'></i></span> Bank OfferExtra 5% off* with Axis Bank Buzz Credit CardT&C</h6>

				<h6><span><i class='fas fa-tag' style='color:green'></i></span> Special PriceGet extra 10% off (price inclusive of discount)T&C</h6>
				<br>
				<div class="input-group">
					<button class="btn btn-info" >Quantity</button><pre></pre>
					<input type="number" name="quan" required="required">
					
				</div><br><br>
				<div class="buy">
				<button type="submit" class="btn btn-danger btn-lg" id="buy1" formaction="order.php">Buy Now</button>
			</div>
			</div>
		</div>
			<div class="col-md-3 third">
				<h4 class="center"><b>Description:-</b></h4>
				<hr>
				<h6><?php echo $row['description']; ?></h6>
			</div>
				
			</div>
		</div>
			</form>
		
<?php
		}
	}
}
?>

<?php include "footer.php"; ?>
</body>
</html>