<!DOCTYPE html>
<html lang="en">
<head>
  <title>RecMed</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://kit.fontawesome.com/18803c92e0.js" crossorigin="anonymous"></script>
  <style type="text/css">
    .modal-login {
    color: #636363;
    width: 400px;
  }
  .modal-login .modal-footer {
    background: #ecf0f1;
    border-color: #dee4e7;
    text-align: center;
    border-radius: 5px;
    font-size: 13px;
    justify-content: center;
  }
  
  

</style>


</head>
<body>

<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
  
  <img src="medicines.png" alt="m" width="50" height="50">
  
  <a class="navbar-brand" href="#"><h5>REC medicines</h5></a>
  
  <!-- Links -->
  
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="sample.html"><h6>Home</h6></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#"><h6>Contact</h6></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#"><h6>About Us</h6></a>
    </li>
    
    </ul>

    <form class="form-inline ml-auto">

                
                <button type="submit" class="btn btn-outline-light" formaction="login.php">Login</button>
                <pre>   </pre>
                <button type="submit" class="btn btn-outline-light" formaction="signup.php">Signup</button>
         
            </form>
</nav>

<div>


  <img src="slide3.jpg" id="slide" style="width:100%">
  
</div>


</div>


<?php include "footer.php"; ?>


</body>
</html>