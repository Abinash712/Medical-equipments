<?php
session_start();
$mail=$_SESSION['user'];
$id=$_SESSION['id'];
$amount=$_POST['place'];
$add=$_POST['add1'].' '.$_POST['add2'].' '.$_POST['state'].'.';
$pin=$_POST['pin'];
include "dbconnect.php";
if($conn)
{
	$query="INSERT into orders(customer_mail,product_id,amount,address,pincode) VALUES
	('$mail',$id,$amount,'$add',$pin)";
	if(mysqli_query($conn,$query))
	{
		header("Location:acknowledge.php");
	}
	
	
}

?>