<!DOCTYPE html>
<html lang="en">
<head>
  <title>RecMed</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://kit.fontawesome.com/18803c92e0.js" crossorigin="anonymous"></script>
  <style type="text/css">
  	body {
		color: #fff;
		background: #19aa8d;
		font-family: 'Roboto', sans-serif;
	}
  	
     .card{
  		height:365px;
  		

  	}
  	#img1{
  		height:200px;
  		width:200px;
  	}
  	#cart{
  		width:108px;
  		float:right;
  		box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
  		margin: 0px 120px 0px 0px;
  	}
  	#view{
  		width:108px;
  		float:left;
  		box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19);
  		margin: 0px 0px 0px 10px;
  	}
  	.card-title{
  		text-align: center;;
  	}
  	.center{
  		text-align: center;
  	}
  	
  	.left{
  		margin-left: 10px;
  	}
  	.head{
  		height:30px;
  	}
  	#empty{
  		margin:40px 0px 0px -500px;
  		height:500px;
  		width:600px;
  	}
  	#heading{
  		color: #000;
  		margin-left: 400px;
  	}
  	.container1 {
  position: relative;
  width: 100%;
  max-width: 400px;
}

.container1 img {
  width: 100%;
  height: auto;
}

.container1 .btn {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  color: white;
  font-size: 16px;
  border: none;
  cursor: pointer;
  border-radius: 5px;
  text-align: center;
  margin:-50px 10px 10px -240px;
}

.container .btn:hover {
  background-color: black;
}
        
  </style>
  	
</head>
<body>
	<?php include "navbar.php"; ?><br><br>
	<div class="container">
	<div class="row">
	<?php
		session_start();
		$mail=$_SESSION['user'];
		include "dbconnect.php";
		if($conn){
			$query="SELECT * from orders o inner join products p where o.product_id=p.product_id and o.customer_mail='$mail'";
			$result=mysqli_query($conn,$query);
			if(mysqli_num_rows($result)>0)
			{
				while($row=mysqli_fetch_assoc($result))
				{

					?>
					
					<div class="col-lg-4 col-sm-2">
			<form method="Post">
			<div class="card">
				<br>
				<h4 class="card-title">Order Id</h4>
				<div class="class-body">
					<h6 class="center"><button class="btn btn-info head">#<?php echo $row['order_id']; ?></button> </h6>
					<hr>
					<h6 class="left">Product Name: <span><?php echo ucwords($row['product_name']); ?></span></h6>
					<h6 class="text-success left">Shipping Address</h6>
					<h6 class="left"><?php echo $row['address']; ?></h6>
					<h6 class="left">Pincode:-<?php echo $row['pincode']; ?></h6> 
					</div>
					<h6 class="left">Total amount: &#8377;<span class="text-success"> <?php echo $row['amount']; ?> </span></h6>
					<hr>
					<div class="but"> 
					<button class="btn btn-danger" id="cart" formaction="cancel.php" value="<?php echo $row['order_id']; ?>" name="cancel">Cancel</button>
				</div>
			</div>
		</form><br><br>
	</div>



<?php
				}
			}
			else{
				echo "<h1 id='heading'>No Orders Found<h1>";
				echo "<div class='container1'><img src='emptycart.png' id='empty'>
				<form>
						<button class='btn btn-danger' formaction='display.php'>Shop Now</button></form>
						</div>";
				}
		}

?>
</div>
</div>	
<?php include "footer.php"; ?>
</body>
</html>