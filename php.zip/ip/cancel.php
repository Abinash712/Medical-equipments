<?php
	$id= $_POST['cancel'];
	include "dbconnect.php";
	if($conn)
	{
		$query="DELETE from orders where order_id=$id";
		if(mysqli_query($conn,$query))
		{
			header("Location:myorders.php");
		}
	}

?>