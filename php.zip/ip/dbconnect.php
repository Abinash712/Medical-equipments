<?php

$servername = "localhost";
$username = "root";
$password = "";
$db="medical";
$conn = mysqli_connect($servername, $username, $password,$db);

?>