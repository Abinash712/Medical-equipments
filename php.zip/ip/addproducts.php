<?php
	$msg='';
 if(filter_has_var(INPUT_POST,"add"))
 {
 	
 	$pname=$_POST['pname'];
 	$price=$_POST['price'];
 	$disc=$_POST['discount'];
 	$desc=$_POST['desc'];
 	$cate=$_POST['cat'];
 	$image=$_POST['image'];
  include "dbconnect.php";
  if($conn)
  {
  	
  	$query="INSERT INTO products(product_name,product_price,description,discount,category,image) VALUES
  	('$pname', $price, '$desc',$disc, '$cate', '$image')";
  	if(mysqli_query($conn,$query))
  	{
  		$msg="Product has been successfully added";
  		$msgClass="alert-success";
  	}
  	else
  	{
  		$msg="Something went wrong! Try again.";
  		$msgClass="alert-danger";
  		
  	}

  
}
}
 ?>






<!DOCTYPE html>
<html lang="en">
<head>
  <title>RecMed</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://kit.fontawesome.com/18803c92e0.js" crossorigin="anonymous"></script>
  <style type="text/css">
  	.containerr {
		color: #fff;
		background: #19aa8d;
		font-family: 'Roboto', sans-serif;
		margin:10px 10px 10px 10px;
	}
	#add{
		margin: 0px 0px 10px 450px;
	}
	h1{
		text-align: center;
		color: #ff6666;
		text-shadow: 1px 1px;
	}
	
</style>
</head>
<body>
	<nav class="navbar navbar-expand-lg bg-dark navbar-dark">
	
  <img src="medicines.png" alt="m" width="50" height="50">
  
  <a class="navbar-brand" href="#"><h5>RecMed</h5></a>
  
  <!-- Links -->
  
  <ul class="navbar-nav">
  	<li class="nav-item">
      <a class="nav-link" href="sample.php"><h6>Home</h6></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#foot"><h6>Contact</h6></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#foot"><h6>About Us</h6></a>
    </li>
    
    </ul>

    <form class="form-inline ml-auto">

                
            
                <button type="submit" class="btn btn-outline-light" formaction="sample.php">Log out</button>
         
            </form>
</nav>
	<h1>Product Details</h1>
	<?php if($msg!=''): ?>
			<div class="alert <?php echo $msgClass; ?>"><?php echo $msg; ?></div>
	<?php endif; ?>
	<div class="container">
		<form action="addproducts.php" method="POST">

			<div class="form-group">
			
				<h6>Product name</h6>
				<input type="text" class="form-control" name="pname" placeholder="Product name" required="required">
			
        </div>
        <div class="form-group">
			
				<h6>Product Price</h6>
				<input type="number" class="form-control" name="price" placeholder="Product price" required="required">

			
        </div>
        <div class="form-group">
        	<h6>Discount</h6>
        	<input type="number" class="form-control" name="discount" placeholder="Discount" required="required">
        </div>
        <div class="form-group">
			
				<h6>Description</h6>
				<textarea class="form-control" rows="3" name="desc" required="required"></textarea>
			
        </div>
        <div class="form-group">
        	<h6>Category</h6>
        	<select class="form-control" name="cat">
        <option>general</option>
        <option>Cardio</option>
        <option>diabetics</option>
        <option>Tablets</option>
      </select>
  </div>

  		<div class="file-field">
  			<h6>Product image</h6>
    <div class="btn btn-secondary">
      
      <input type="file" name="image" required="required">
    </div>
  </div>

  		<div class="form-group">
  			<button class="btn btn-danger" id="add" name="add">CLICK TO ADD</button>
  		</div>
			</form>
	</div>
<?php include "footer.php"; ?>
</body>
</html>