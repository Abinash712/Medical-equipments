<!DOCTYPE html>
<html lang="en">
<head>
  <title>RecMed</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
  <script src="https://kit.fontawesome.com/18803c92e0.js" crossorigin="anonymous"></script>
  <style type="text/css">
    .back{
      background-color:#001a33;
    }
    .color{
      color: white;
    }
  </style>
</head>
<body>





<!-- Footer -->
<footer class="page-footer font-small back" id="foot">

  <div style="background-color: #001a20;">
    <div class="container">
      <div class="row py-4 d-flex align-items-center">

        
        <div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
          <h6 class="mb-0 color">Get connected with us on social networks!</h6>
        </div>
        <div class="col-md-6 col-lg-7 text-center text-md-right">
          <a class="fb-ic">
            <i class="fab fa-facebook-f white-text mr-4 color"> </i>
          </a>
         
          <a class="tw-ic">
            <i class="fab fa-twitter white-text mr-4 color"> </i>
          </a>
          
          <a class="gplus-ic">
            <i class="fab fa-google-plus-g white-text mr-4 color"> </i>
          </a>
         
          <a class="li-ic">
            <i class="fab fa-linkedin-in white-text mr-4 color"> </i>
          </a>
          <a class="ins-ic">
            <i class="fab fa-instagram white-text color"> </i>
          </a>

        </div>
        

      </div>
     

    </div>
  </div>
  
  <div class="container text-center text-md-left mt-5">
    <div class="row mt-3">
      <div class="col-md-4 col-lg-4 col-xl-3 mx-auto mb-4">
        <h6 class="text-uppercase font-weight-bold color">About Us</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p class="color">We are RecMed- Tamil Nadu’s highest rated online medical representative website. We deliver medicical equiments, healthcare products right to your doorstep.
</p><p class="color">
Founded in 2018 by Dinesh and Dr.Abinash, we have more than 100+ committed employees working towards our collective goal of making healthcare easy and affordable.</p>

      </div>
      <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
        <h6 class="text-uppercase font-weight-bold color">Products</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
          <a href="#!">Medical Equiments</a>
        </p>
        <p>
          <a href="#!">Pharmaceutical</a>
        </p>
        <p>
          <a href="#!">Tablets</a>
        </p>
        <p>
          <a href="#!"></a>
        </p>

      </div>
      <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
        <h6 class="text-uppercase font-weight-bold color">Useful links</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p>
          <a href="#!">Your Account</a>
        </p>
        <p>
          <a href="#!">Become an Affiliate</a>
        </p>
        <p>
          <a href="#!">Shipping Rates</a>
        </p>
        <p>
          <a href="#!">Help</a>
        </p>

      </div>
      <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">

        <!-- Links -->
        <h6 class="text-uppercase font-weight-bold color">Contact</h6>
        <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        <p class="color">
          <i class="fas fa-home mr-3"></i> Thandalam, Chennai</p>
        <p class="color">
          <i class="fas fa-envelope mr-3"></i> info@recmed.com</p>
        <p class="color">
          <i class="fas fa-phone mr-3"></i> + 91 9787678899</p>
        <p class="color">
          <i class="fas fa-print mr-3"></i> + 01 234 567 89</p>

      </div>
    </div>

  </div>
  <div class="footer-copyright text-center py-3 color">© 2019 Copyright
    
  </div>
</footer>
</body>
</html>